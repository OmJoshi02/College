package Maths;

public class Ceil {
    public static double applyCeil(double num){
        return Math.ceil(num);
    }
}
