package Maths;

public class Round {
    public static double applyRound(double num){
        return Math.round(num);
    }
}
