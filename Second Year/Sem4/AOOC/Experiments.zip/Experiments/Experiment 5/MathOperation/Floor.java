package Maths;

public class Floor{

    public static double applyFloor(double num){
        return Math.floor(num);
    }

}