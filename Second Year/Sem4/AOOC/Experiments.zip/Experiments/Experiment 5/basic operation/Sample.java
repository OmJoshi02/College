package p1;

public class Sample{

    public void display(){
        System.out.println("Hello world this is sample file");
    }
}