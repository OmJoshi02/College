import p1.sample;
import p1.p11.sample1;

public class Main {
    public static void main(String[] args){

        sample ob = new sample();
        sample1 ob1 = new sample1();
        
        ob.display();
        ob1.display1();
        
    }
}
