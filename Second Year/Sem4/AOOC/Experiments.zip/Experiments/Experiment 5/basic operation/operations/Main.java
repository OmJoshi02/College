import java.util.*;
import operations.Arithmetic;

public class Main {

    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter first no. : ");
        int num1 = scan.nextInt();

        System.out.println("Enter second no. : ");
        int num2 = scan.nextInt();

        Arithmetic ob = new Arithmetic();

        

        while (true) {
            System.out.println("Enter your choice");
            
            System.out.println("1. Add");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiiplication");
            System.out.println("4. Division");

            int choice = scan.nextInt();

            switch (choice) {
                case 1:
                        int a1 = ob.add(num1, num2);
                        System.out.println(a1);
                    break;
            
                case 2:
                        int a2 = ob.sub(num1, num2);
                        System.out.println(a2);
                    break;

                case 3:
                        int a3 = ob.multi(num1, num2);
                        System.out.println(a3);
                    break;

                case 4:
                        int a4 = ob.div(num1, num2);
                        System.out.println(a4);
                    break;

                default:
                        System.out.println("Enter correct choice");
                    break;

            
            }
        }
        
    }
    
}
