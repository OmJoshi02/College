package operations;

public class Arithmetic{

    public int add(int a, int b){
        return a+b;
    }

    public int sub(int a, int b){
        return a-b;
    }

    public int multi(int a, int b){
        return a*b;
    }

    public int div(int a, int b){
        return a/b;
    }
}