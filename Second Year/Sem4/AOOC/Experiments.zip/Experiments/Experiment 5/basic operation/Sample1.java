package p1.p11;

public class Sample1 {
    
    public void display1(){
        System.out.println("Hello world this is sample1");
    }
}
