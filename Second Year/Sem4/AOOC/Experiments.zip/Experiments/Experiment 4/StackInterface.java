import java.util.*;

public class StackInterface {

    interface Stack {
        void push(int val);
        int pop();
        void display();
    }

    static class IntegerStack implements Stack {
        private int top;
        private int size;
        private int[] stack;

        public IntegerStack(int size) {
            this.size = size;
            this.stack = new int[size];
            this.top = -1;
        }

        @Override
        public void push(int val) {
            if (top == size - 1) {
                System.out.println("Stack is full, cannot push " + val);
            } else {
                stack[++top] = val;
                System.out.println(val + " pushed into the stack");
            }
        }

        @Override
        public int pop() {
            if (top == -1) {
                System.out.println("Stack is empty, cannot pop");
                return -1;
            } else {
                System.out.println(stack[top] + " popped from the stack");
                return stack[top--];
            }
        }

        @Override
        public void display() {
            if (top == -1) {
                System.out.println("Stack is empty");
            } else {
                System.out.print("Stack: ");
                for (int i = 0; i <= top; i++) {
                    System.out.print(stack[i] + " ");
                }
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the size of the stack: ");
        int n = scan.nextInt();
        IntegerStack stack = new IntegerStack(n); // Corrected object creation

        while (true) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scan.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter value to push: ");
                    int val = scan.nextInt();
                    stack.push(val);
                    break;
                case 2:
                    stack.pop();
                    break;
                case 3:
                    stack.display();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scan.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

