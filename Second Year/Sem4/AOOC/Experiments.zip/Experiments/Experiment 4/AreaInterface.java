import java.util.*;

class AreaInterface {
    
    interface Shape {
        double area();sheetssheets
   
    }

    static class Rectangle implements Shape {
        double length, breadth;

        public Rectangle(double length, double breadth) {
            this.length = length;
            this.breadth = breadth;
        }

        @Override
        public double area() {
            return length * breadth;
        }
    }

    static class Triangle implements Shape {
        double height, base;

        public Triangle(double height, double base) {
            this.height = height;
            this.base = base;
        }

        @Override
        public double area() {
            return 0.5 * height * base; 
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter length of rectangle: ");
        double length = scan.nextDouble();
        System.out.print("Enter breadth of rectangle: ");
        double breadth = scan.nextDouble();

        Rectangle rect = new Rectangle(length, breadth);

        System.out.print("Enter height of triangle: ");
        double height = scan.nextDouble();
        System.out.print("Enter base of triangle: ");
        double base = scan.nextDouble();

        Triangle tri = new Triangle(height, base);

        System.out.println("Area of rectangle: " + rect.area());
        System.out.println("Area of triangle: " + tri.area());

        scan.close();
    }
}

