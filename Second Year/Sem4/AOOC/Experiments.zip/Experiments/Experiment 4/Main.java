
class Student {
    int roll;

    int getRoll() {
        return roll;
    }

    void setRoll(int roll) {
        this.roll = roll;
    }
}

class Test extends Student {
    int sub1;
    int sub2;

    int getSub1Marks() {
        return sub1;
    }

    int getSub2Marks() {
        return sub2;
    }

    void setMarks(int sub1, int sub2) {
        this.sub1 = sub1;
        this.sub2 = sub2;
    }
}

interface Sports {
    int sMarks = 10; // Implicitly public, static, and final
    void set();
}

class Result extends Test implements Sports {
    int totalMarks;

    @Override
    public void set() {}

    public void display() {
        totalMarks = getSub1Marks() + getSub2Marks() + sMarks;
        System.out.println("Roll no: " + getRoll());
        System.out.println("Marks in subject 1: " + getSub1Marks());
        System.out.println("Marks in subject 2: " + getSub2Marks());
        System.out.println("Sports marks: " + sMarks);
        System.out.println("Total marks: " + totalMarks);
    }
}

// Renamed from Student to avoid duplicate class error
public class Main {
    public static void main(String[] args) {
        Result r = new Result();
        r.setRoll(111);
        r.setMarks(90, 90);
        r.set();
        r.display();
    }
}
