package ExceptionHandlingDemo;

public class DivisionException extends Exception {

    public DivisionException(String message) {
        super(message);
    }
}
