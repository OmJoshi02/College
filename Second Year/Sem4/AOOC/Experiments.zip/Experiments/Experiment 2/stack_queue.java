import java.util.*;

class stack_queue {

    private Stack<Integer> stack = new Stack<>();

    void push(int val){
        stack.push(val);
        System.out.println(val+" pushed in stack");
    }

    int pop(){
        if(stack.isEmpty()){
            System.out.println("Stack is empty");
            return -1;
        }
        else{
            return stack.pop();
        }

    }

    void display(){
        System.out.println("Stack : "+stack);
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        stack_queue stack = new stack_queue();
        
        System.out.print("Enter the size of stack : ");
        int n = scan.nextInt();
        
        for(int i = 0; i < n; i++){
            System.out.println("Enter element "+i+" : ");
            int val = scan.nextInt();
            stack.push(val);
            System.out.println();
        }

        stack.display();

        for(int i = 0; i < n; i++){
            stack.pop();
            stack.display();
        }
        
    
    }
}
