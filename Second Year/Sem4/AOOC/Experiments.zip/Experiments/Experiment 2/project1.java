import java.util.*;

public class project1{

static class StackQueue {
    private int[] stack;
    private int top;
    private int size;

    public StackQueue(int size) {
        this.size = size;
        stack = new int[size];
        top = -1;
    }

    void push(int val) {
        if (top == size - 1) {
            System.out.println("Stack is full, cannot push");
        } else {
            stack[++top] = val;
            System.out.println(val + " pushed in stack");
        }
    }

    int pop() {
        if (top == -1) {
            System.out.println("Stack is empty");
            return -1;
        } else {
            int popped = stack[--top];
            System.out.println(popped+" popped from stack.");
            return popped;
        }
    }

    void display() {
        if (top == -1) {
            System.out.println("Stack is empty");
        } else {
            System.out.println("Stack:");
            for (int i = 0; i <= top; i++) {
                System.out.print(stack[i] + " ");
            }
            System.out.println();
        }
    }

    
}

public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.print("Enter the size of the stack: ");
    int n = scan.nextInt();
    StackQueue stack = new StackQueue(n); // Creating a stack of size 'n'


    while (true) {
        System.out.println("\nChoose an operation:");
        System.out.println("1. Push");
        System.out.println("2. Pop");
        System.out.println("3. Display");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
        
        int choice = scan.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter value to push: ");
                int val = scan.nextInt();
                stack.push(val);
                break;
            case 2:
                stack.pop();
                break;
            case 3:
                stack.display();
                break;
            case 4:
                System.out.println("Exiting...");
                scan.close();
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}

}
